X = int(input())
Y = int(input())
Z = 1 / (X*Y)
print(Z)