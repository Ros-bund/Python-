# Вводим размеры
a = int(input())
b = int(input())
c = int(input())
m = int(input())
k = int(input())

# Простая проверка - если хоть одна комбинация проходит
if ((a <= m and b <= k) or (a <= k and b <= m) or
    (a <= m and c <= k) or (a <= k and c <= m) or
    (b <= m and c <= k) or (b <= k and c <= m)):
    print("Проходит")
else:
    print("Не проходит")